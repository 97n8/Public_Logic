import React from "react";
import { Link } from "react-router";
import { Shield, Twitter, Linkedin, Mail } from "lucide-react";

export function Footer() {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="relative bg-emerald-950/80 border-t border-white/10 pt-20 pb-10 overflow-hidden">
      {/* Footer background element */}
      <div className="absolute bottom-0 right-0 w-[300px] h-[300px] bg-emerald-800/20 blur-[100px] rounded-full pointer-events-none" aria-hidden="true" />

      <div className="container mx-auto px-6 relative z-10">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-16">
          <div className="col-span-1 md:col-span-2">
            <Link to="/" className="flex items-center gap-2 mb-6 group">
              <div className="p-1.5 rounded-lg bg-emerald-500 shadow-lg shadow-emerald-500/20">
                <Shield className="w-5 h-5 text-emerald-950" aria-hidden="true" />
              </div>
              <span className="text-2xl font-bold tracking-tight text-white group-hover:text-emerald-400 transition-colors">
                Public<span className="text-emerald-400">Logic</span>
              </span>
            </Link>
            <p className="text-emerald-100/60 max-w-sm mb-8 text-lg font-medium">
              Specializing in durable governance for Massachusetts towns using our proprietary VAULT™ framework. Structure-first, community-driven.
            </p>
            <div className="flex gap-4">
              <SocialLink href="#" icon={<Linkedin className="w-5 h-5" />} label="LinkedIn" />
              <SocialLink href="#" icon={<Twitter className="w-5 h-5" />} label="Twitter" />
              <SocialLink href="mailto:info@publiclogic.com" icon={<Mail className="w-5 h-5" />} label="Email" />
            </div>
          </div>

          <div>
            <h4 className="text-white font-bold mb-6 text-sm uppercase tracking-widest">Solutions</h4>
            <ul className="space-y-4">
              <li><FooterLink to="/services">VAULT™ Framework</FooterLink></li>
              <li><FooterLink to="/services">Strategic Planning</FooterLink></li>
              <li><FooterLink to="/services">AI for Impact Pilot</FooterLink></li>
              <li><FooterLink to="/services">Interim Governance</FooterLink></li>
            </ul>
          </div>

          <div>
            <h4 className="text-white font-bold mb-6 text-sm uppercase tracking-widest">Company</h4>
            <ul className="space-y-4">
              <li><FooterLink to="/about">About Us</FooterLink></li>
              <li><FooterLink to="/writing">Writing & Insights</FooterLink></li>
              <li><FooterLink to="/contact">Contact</FooterLink></li>
              <li><FooterLink to="#">Privacy Policy</FooterLink></li>
            </ul>
          </div>
        </div>

        <div className="pt-10 border-t border-white/5 flex flex-col md:flex-row justify-between items-center gap-6">
          <p className="text-emerald-100/40 text-sm font-medium">
            &copy; {currentYear} PublicLogic LLC. VAULT™ is a trademark of PublicLogic.
          </p>
          <p className="text-emerald-100/40 text-sm font-medium flex items-center gap-2">
            Built with integrity for the Commonwealth of Massachusetts.
          </p>
        </div>
      </div>
    </footer>
  );
}

function SocialLink({ href, icon, label }: { href: string, icon: React.ReactNode, label: string }) {
  return (
    <a 
      href={href} 
      className="w-10 h-10 rounded-full bg-emerald-900/50 flex items-center justify-center text-emerald-400 hover:bg-emerald-500 hover:text-emerald-950 transition-all shadow-xl hover:scale-110 active:scale-95"
      aria-label={label}
    >
      {React.cloneElement(icon as React.ReactElement, { "aria-hidden": "true" })}
    </a>
  );
}

function FooterLink({ to, children }: { to: string, children: React.ReactNode }) {
  return (
    <Link to={to} className="text-emerald-100/60 hover:text-emerald-400 transition-colors font-medium">
      {children}
    </Link>
  );
}
