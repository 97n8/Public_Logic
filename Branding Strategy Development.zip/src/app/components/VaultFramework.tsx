import React, { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Shield, Target, Zap, Lock, Users, ChevronRight } from "lucide-react";

interface Pillar {
  id: string;
  letter: string;
  title: string;
  description: string;
  icon: React.ReactNode;
  color: string;
  details: string[];
}

const pillars: Pillar[] = [
  {
    id: "v",
    letter: "V",
    title: "Verification",
    description: "Deep evidentiary bases for administrative decisions.",
    icon: <Shield className="w-6 h-6" aria-hidden="true" />,
    color: "bg-emerald-500",
    details: ["Administrative Audits", "Evidence-Based Policy", "Compliance Reviews"]
  },
  {
    id: "a",
    letter: "A",
    title: "Alignment",
    description: "Synchronizing values with legal mandates.",
    icon: <Target className="w-6 h-6" aria-hidden="true" />,
    color: "bg-emerald-400",
    details: ["Community Visioning", "Legal Mandate Mapping", "Strategic Planning"]
  },
  {
    id: "u",
    letter: "U",
    title: "Utility",
    description: "Practical implementations that deliver citizen value.",
    icon: <Zap className="w-6 h-6" aria-hidden="true" />,
    color: "bg-emerald-300",
    details: ["Workflow Optimization", "Service Delivery Design", "Digital Modernization"]
  },
  {
    id: "l",
    letter: "L",
    title: "Legitimacy",
    description: "Strengthening procedural integrity and trust.",
    icon: <Lock className="w-6 h-6" aria-hidden="true" />,
    color: "bg-emerald-200",
    details: ["Town Meeting Support", "Electoral Integrity", "Public Transparency"]
  },
  {
    id: "t",
    letter: "T",
    title: "Trust",
    description: "The ultimate output of resilient governance.",
    icon: <Users className="w-6 h-6" aria-hidden="true" />,
    color: "bg-white",
    details: ["Citizen Engagement", "Long-term Stability", "Accountability Systems"]
  }
];

export function VaultFramework() {
  const [activePillar, setActivePillar] = useState<Pillar>(pillars[0]);

  return (
    <div className="w-full">
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
        {/* Navigation Sidebar */}
        <div className="lg:col-span-5 flex flex-col gap-4">
          {pillars.map((pillar) => (
            <button
              key={pillar.id}
              onClick={() => setActivePillar(pillar)}
              aria-pressed={activePillar.id === pillar.id}
              className={`group flex items-center gap-6 p-6 rounded-2xl border transition-all text-left outline-none focus-visible:ring-2 focus-visible:ring-emerald-400 ${
                activePillar.id === pillar.id
                  ? "bg-emerald-600 border-emerald-400 shadow-xl shadow-emerald-900/40 translate-x-4"
                  : "bg-white/5 border-white/10 hover:bg-white/10"
              }`}
            >
              <div className={`flex-shrink-0 w-12 h-12 rounded-xl flex items-center justify-center font-black text-xl transition-colors ${
                activePillar.id === pillar.id 
                  ? "bg-white text-emerald-600" 
                  : "bg-emerald-500/20 text-emerald-400 group-hover:bg-emerald-500 group-hover:text-emerald-950"
              }`}>
                {pillar.letter}
              </div>
              <div>
                <h4 className={`font-bold text-lg mb-1 transition-colors ${
                  activePillar.id === pillar.id ? "text-white" : "text-emerald-100/80"
                }`}>
                  {pillar.title}
                </h4>
                <p className={`text-sm leading-snug transition-colors ${
                  activePillar.id === pillar.id ? "text-emerald-100/70" : "text-emerald-100/60"
                }`}>
                  {pillar.description}
                </p>
              </div>
              <ChevronRight className={`ml-auto w-5 h-5 transition-transform ${
                activePillar.id === pillar.id ? "text-white rotate-0" : "text-emerald-100/20 -rotate-90"
              }`} aria-hidden="true" />
            </button>
          ))}
        </div>

        {/* Content Display */}
        <div className="lg:col-span-7">
          <AnimatePresence mode="wait">
            <motion.div
              key={activePillar.id}
              initial={{ opacity: 0, scale: 0.95, x: 20 }}
              animate={{ opacity: 1, scale: 1, x: 0 }}
              exit={{ opacity: 0, scale: 0.95, x: -20 }}
              transition={{ duration: 0.4, ease: "easeOut" }}
              className="bg-emerald-950/40 backdrop-blur-xl border border-white/10 rounded-[3rem] p-12 relative overflow-hidden h-full min-h-[500px] flex flex-col justify-center shadow-3xl"
              role="region"
              aria-label={`${activePillar.title} pillar details`}
            >
              {/* Decorative Glow */}
              <div 
                className={`absolute -top-24 -right-24 w-64 h-64 blur-[100px] rounded-full opacity-20 pointer-events-none ${activePillar.color}`} 
                aria-hidden="true"
              />
              
              <div className="relative z-10">
                <div className={`w-20 h-20 rounded-3xl mb-8 flex items-center justify-center shadow-2xl ${activePillar.color} text-emerald-950`}>
                  {React.cloneElement(activePillar.icon as React.ReactElement, { className: "w-10 h-10" })}
                </div>
                
                <h3 className="text-4xl md:text-5xl font-black text-white mb-6 tracking-tight">
                  {activePillar.title}
                </h3>
                
                <p className="text-xl text-emerald-100/70 mb-10 leading-relaxed max-w-xl font-medium">
                  {activePillar.description} In the VAULT™ framework, {activePillar.title.toLowerCase()} serves as a critical checkpoint to ensure all municipal actions are both legally sound and socially resonant.
                </p>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {activePillar.details.map((detail, idx) => (
                    <div 
                      key={idx}
                      className="flex items-center gap-3 p-4 rounded-xl bg-white/5 border border-white/5 text-emerald-100 font-bold"
                    >
                      <div className="w-2.5 h-2.5 rounded-full bg-emerald-500 shadow-[0_0_10px_rgba(16,185,129,0.5)]" aria-hidden="true" />
                      {detail}
                    </div>
                  ))}
                </div>
                
                <div className="mt-12 pt-8 border-t border-white/5">
                  <p className="text-emerald-100/60 text-xs font-bold uppercase tracking-widest mb-2">Pillar Role</p>
                  <p className="text-white font-bold italic text-lg">
                    "Ensuring the structural integrity of every town decision, from the selectboard to the meeting floor."
                  </p>
                </div>
              </div>
            </motion.div>
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
}
