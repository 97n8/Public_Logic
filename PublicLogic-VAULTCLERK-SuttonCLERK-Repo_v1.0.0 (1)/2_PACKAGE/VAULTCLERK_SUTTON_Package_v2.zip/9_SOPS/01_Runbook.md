# Clerk Runbook (Daily)
1) Open Queue by due date.
2) Validate metadata and attachments.
3) Request info / reassign as needed.
4) Publish public copy when approved.
