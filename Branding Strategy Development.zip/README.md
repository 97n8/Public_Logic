
  # Branding Strategy Development

  This is a code bundle for Branding Strategy Development. The original project is available at https://www.figma.com/design/Q4tO7Y8QN1nelP5b0rg3AJ/Branding-Strategy-Development.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  