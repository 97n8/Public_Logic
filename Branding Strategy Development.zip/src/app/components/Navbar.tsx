import React, { useState, useEffect } from "react";
import { Link, useLocation } from "react-router";
import { motion, AnimatePresence } from "motion/react";
import { Menu, X, Shield, Sparkles, ArrowRight } from "lucide-react";

export function Navbar() {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const location = useLocation();

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const navLinks = [
    { name: "Home", path: "/" },
    { name: "About", path: "/about" },
    { name: "Services", path: "/services" },
    { name: "Writing", path: "/writing" },
    { name: "Contact", path: "/contact" },
  ];

  return (
    <nav 
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ease-in-out ${
        scrolled ? "py-4" : "py-8"
      }`}
    >
      <div className="container mx-auto px-6">
        <div className={`relative flex items-center justify-between rounded-3xl px-8 py-3.5 transition-all duration-500 ${
          scrolled 
            ? "bg-emerald-950/60 backdrop-blur-2xl border border-white/10 shadow-[0_20px_50px_rgba(0,0,0,0.3)]" 
            : "bg-transparent border-transparent"
        }`}>
          {/* Logo */}
          <Link to="/" className="flex items-center gap-3 group">
            <div className="p-2 rounded-xl bg-emerald-500 group-hover:bg-emerald-400 transition-all duration-300 shadow-[0_0_20px_rgba(16,185,129,0.4)] group-hover:shadow-[0_0_30px_rgba(16,185,129,0.6)] group-hover:scale-110 active:scale-95">
              <Shield className="w-5 h-5 text-emerald-950" strokeWidth={3} />
            </div>
            <span className="text-2xl font-black tracking-tighter text-white uppercase italic">
              Public<span className="text-emerald-400">Logic</span>
            </span>
          </Link>

          {/* Desktop Nav */}
          <div className="hidden md:flex items-center gap-10">
            {navLinks.map((link) => (
              <Link
                key={link.path}
                to={link.path}
                className={`relative text-sm font-bold tracking-widest uppercase transition-colors hover:text-emerald-400 flex items-center gap-1.5 ${
                  location.pathname === link.path ? "text-emerald-400" : "text-emerald-100/60"
                }`}
              >
                {link.name}
                {link.name === "Services" && (
                  <span className="flex h-1.5 w-1.5 rounded-full bg-emerald-400 animate-pulse" />
                )}
                {location.pathname === link.path && (
                  <motion.div
                    layoutId="nav-underline"
                    className="absolute -bottom-1.5 left-0 right-0 h-0.5 bg-emerald-400 rounded-full"
                    transition={{ type: "spring", stiffness: 400, damping: 30 }}
                  />
                )}
              </Link>
            ))}
            <Link 
              to="/services" 
              className="hidden lg:flex items-center gap-2 bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 px-4 py-1.5 rounded-full text-xs font-bold transition-all hover:bg-emerald-500/20"
            >
              <Sparkles className="w-3.5 h-3.5" /> AI Pilot
            </Link>
            <Link 
              to="/contact" 
              className="group relative flex items-center gap-2 bg-white text-emerald-950 px-6 py-2.5 rounded-xl text-sm font-black uppercase tracking-wider transition-all hover:bg-emerald-400 hover:text-emerald-950 hover:scale-105 active:scale-95 overflow-hidden"
            >
              <span className="relative z-10">Get Started</span>
              <ArrowRight className="w-4 h-4 relative z-10 transition-transform group-hover:translate-x-1" />
              <div className="absolute inset-0 bg-emerald-400 translate-y-full group-hover:translate-y-0 transition-transform duration-300" />
            </Link>
          </div>

          {/* Mobile Toggle */}
          <button 
            className="md:hidden p-2 rounded-xl bg-white/5 border border-white/10 text-emerald-100"
            onClick={() => setIsOpen(!isOpen)}
          >
            {isOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: -20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: -20 }}
            transition={{ type: "spring", duration: 0.5 }}
            className="absolute top-full left-6 right-6 mt-4 md:hidden bg-emerald-950/95 backdrop-blur-3xl border border-white/10 rounded-[2.5rem] shadow-3xl overflow-hidden z-50"
          >
            <div className="p-10 flex flex-col gap-8">
              {navLinks.map((link) => (
                <Link
                  key={link.path}
                  to={link.path}
                  onClick={() => setIsOpen(false)}
                  className={`text-3xl font-black tracking-tighter uppercase italic transition-colors flex items-center justify-between ${
                    location.pathname === link.path ? "text-emerald-400" : "text-emerald-100"
                  }`}
                >
                  {link.name}
                  {link.name === "Services" && <Sparkles className="w-5 h-5 text-emerald-400" />}
                </Link>
              ))}
              <div className="h-px bg-white/10 my-2" />
              <Link
                to="/contact"
                onClick={() => setIsOpen(false)}
                className="flex items-center justify-center gap-3 bg-emerald-500 text-emerald-950 py-5 rounded-2xl text-xl font-black uppercase tracking-widest"
              >
                Start Engagement <ArrowRight className="w-6 h-6" />
              </Link>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
}
